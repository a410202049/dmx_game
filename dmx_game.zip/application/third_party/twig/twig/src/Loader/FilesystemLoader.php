<?php

namespace Twig\Loader;

class_exists('Twig_Loader_Filesystem');

if (\false) {
    class FilesystemLoader extends \Twig_Loader_Filesystem
    {
    }
}
