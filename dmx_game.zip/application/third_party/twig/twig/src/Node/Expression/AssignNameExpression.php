<?php

namespace Twig\Node\Expression;

class_exists('Twig_Node_Expression_AssignName');

if (\false) {
    class AssignNameExpression extends \Twig_Node_Expression_AssignName
    {
    }
}
