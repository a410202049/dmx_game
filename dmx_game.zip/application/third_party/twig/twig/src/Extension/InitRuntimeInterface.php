<?php

namespace Twig\Extension;

class_exists('Twig_Extension_InitRuntimeInterface');

if (\false) {
    interface InitRuntimeInterface extends \Twig_Extension_InitRuntimeInterface
    {
    }
}
