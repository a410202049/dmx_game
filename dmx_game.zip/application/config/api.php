<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| API REQUEST SETTINGS
| -------------------------------------------------------------------
*/
// host
$config['xxx_api']['host'] = 'http://fanyi.baidu.com/';
$config['xxx_api']['uri'] = array(
    'xxx_ooo' => 'langdetect',
);
// // 需要做log的api
// $config['xxx_api']['request_log'] = array(
//     'xxx_ooo',
// );


